from generateKey import generateKey
from generateKey import getSmallPrimeNumbers

print()
getSmallPrimeNumbers(100000)
generateKey()
print()
print("     Done")
print()